package com.web;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Bank {
@Id
private int acountnum;
private String name;
private String password;
private String confirmps;
private double amount;
private long mobilenum;
private String addres;

public Bank() {
	super();
}
public Bank(int acountnum, String name, String password, String confirmps, double amount, String addres,
		long mobilenum) {
	super();
	this.acountnum = acountnum;
	this.name = name;
	this.password = password;
	this.confirmps = confirmps;
	this.amount = amount;
	this.addres = addres;
	this.mobilenum = mobilenum;
}
public int getAcountnum() {
	return acountnum;
}
public void setAcountnum(int acountnum) {
	this.acountnum = acountnum;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getConfirmps() {
	return confirmps;
}
public void setConfirmps(String confirmps) {
	this.confirmps = confirmps;
}
public double getAmount() {
	return amount;
}
public void setAmount(double amount) {
	this.amount = amount;
}
public String getAddres() {
	return addres;
}
public void setAddres(String addres) {
	this.addres = addres;
}
public long getMobilenum() {
	return mobilenum;
}
public void setMobilenum(long mobilenum) {
	this.mobilenum = mobilenum;
}
@Override
public String toString() {
	return "Bank [acountnum=" + acountnum + ", name=" + name + ", password=" + password + ", confirmps=" + confirmps
			+ ", amount=" + amount + ", addres=" + addres + ", mobilenum=" + mobilenum + "]";
}


}