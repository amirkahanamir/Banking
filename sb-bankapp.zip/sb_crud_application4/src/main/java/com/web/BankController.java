package com.web;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class BankController {
	@Autowired
	private BankService service;
	private Bank1 bank1;
	private Bank bank;
	

@RequestMapping("/")
public String home() {
	return "home";
	}
@RequestMapping("/start")
public String homepage() {
	return "home";
	}
@RequestMapping("newaccount")
public String register(Bank bank,ModelMap model) {
	Bank pro=new Bank();
	model.addAttribute("Bank", bank);
	return "reg";
}
@RequestMapping("register")
public String save(@ModelAttribute Bank bank,ModelMap model) {
	Bank banks=service.savebank(bank);
return "bank";
}
@RequestMapping("balance")
public String balance(Bank bank, ModelMap model) {
	Bank balance=new Bank();
	balance.setAcountnum(bank.getAcountnum());
	balance.setName(bank.getName());
	balance.setPassword(bank.getPassword());
	return "balance";
	
}
@RequestMapping("balsuccess")
public String balancecheck(ModelMap model,Bank bank) {
	model.put("Bank",service.findbyid(bank) );
	return "balsuccess";
	
}
@RequestMapping("Deposit")
public String doposit(Bank bank,ModelMap model) {
	Bank repo=new Bank();
	return "deposit";
	
}
@RequestMapping("Deposucces")
public String doposite(Bank bank,ModelMap model) {
	Bank repo=new Bank();
	model.put("with", service.deposit(bank));
	return "deposec";
	
}
@RequestMapping("withdraw")
public String withdraw(Bank bank,ModelMap model) {
	Bank with=new Bank();
	return "withdra";
	}
@RequestMapping("withdrasuccess")
public String with(ModelMap model,Bank bank) {
	model.put("with",service.withdra(bank));
	return "withdras";
	
}
@RequestMapping("Transfer")
public String Transfer(ModelMap model,Bank1 bank1) {
	Bank1 ban=new Bank1();
	model.addAttribute("with",ban);
	return "transfer";
	
}
@RequestMapping("trancesucces")
public String trancesucces(@ModelAttribute Bank1 bank1,ModelMap model) {
	
	
	/*model.put("with",lists.get(0).getAmount()+bank.getAmount());
	model.put("with",lists.get(0).getAmount());
	
	model.put("with",lists.get(1).getAmount());
	model.put("with",lists.get(1).getAmount()-bank.getAmount());*/
	model.put("with",service.trancefor(bank1));
	return "trancesuc";
}
@RequestMapping("close")
public String close(ModelMap model,Bank bank) {
	model.addAttribute("bank",bank);
	return "close";
}
@RequestMapping("closesuc")
public String closesuc(ModelMap model,Bank bank) {
  model.addAttribute("bank",service.delete(bank));
	return "closesuc";
}
@RequestMapping("aboutus")
public String about(@ModelAttribute Bank bank) {
  Bank about=new Bank();
	return "about";
	
}
}