package com.web;

import javax.persistence.Entity;
import javax.persistence.Id;


public class Bank1 {

	private int acountnum;
	private String name;
	private String password;
	private double amount;
	private long mobilenum;
	private String addres;
	private int toacountnum;
	public Bank1() {
		super();
	}
	public Bank1(int acountnum, String name, String password, double amount, long mobilenum, String addres,
			int toacountnum) {
		super();
		this.acountnum = acountnum;
		this.name = name;
		this.password = password;
		this.amount = amount;
		this.mobilenum = mobilenum;
		this.addres = addres;
		this.toacountnum = toacountnum;
	}
	public int getAcountnum() {
		return acountnum;
	}
	public void setAcountnum(int acountnum) {
		this.acountnum = acountnum;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public long getMobilenum() {
		return mobilenum;
	}
	public void setMobilenum(long mobilenum) {
		this.mobilenum = mobilenum;
	}
	public String getAddres() {
		return addres;
	}
	public void setAddres(String addres) {
		this.addres = addres;
	}
	public int getToacountnum() {
		return toacountnum;
	}
	public void setToacountnum(int toacountnum) {
		this.toacountnum = toacountnum;
	}
	@Override
	public String toString() {
		return "Bank1 [acountnum=" + acountnum + ", name=" + name + ", password=" + password + ", amount=" + amount
				+ ", mobilenum=" + mobilenum + ", addres=" + addres + ", toacountnum=" + toacountnum + "]";
	}
	
}