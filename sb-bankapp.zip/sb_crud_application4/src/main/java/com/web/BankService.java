package com.web;
import java.util.List;
public interface BankService {
	public Bank savebank(Bank bank);
	public Bank findbyid(Bank bank);
	public Bank deposit(Bank bank);
	public Bank withdra(Bank bank);
	public List<Bank> trancefor(Bank1 bank);
	public Bank delete(Bank acountnum);
}
