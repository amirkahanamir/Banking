package com.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class BankServiceImp implements BankService {
  @Autowired
  private BankRepo repo;
private List<Bank> list;

	@Override
	public Bank savebank(Bank bank) {
		Bank save =repo.save(bank);
		return save;
	}

	@Override
	public Bank findbyid(Bank bank) {
		Bank Bank1=repo.findById(bank.getAcountnum()).get();
		return Bank1;
		
	}
		
	@Override
	public Bank withdra(Bank bank) {
		Bank  Bank1 =repo.findById(bank.getAcountnum()).get();
		if (Bank1.getAcountnum()==bank.getAcountnum()&&bank.getName().equalsIgnoreCase(bank.getName())&&bank.getPassword().equals(Bank1.getPassword())) {
			Bank1.setAmount(Bank1.getAmount()-bank.getAmount());
			repo.save(Bank1);
			
			return  Bank1;
		}
		else {
			return null;
		}

	}

	
	@Override
	public Bank deposit(Bank bank) {
		
		Bank  Bank1 =repo.findById(bank.getAcountnum()).get();
		if (Bank1.getAcountnum()==bank.getAcountnum()&&bank.getName().equalsIgnoreCase(bank.getName())&&bank.getPassword().equals(Bank1.getPassword())) {
			Bank1.setAmount(Bank1.getAmount()+bank.getAmount());
			repo.save(Bank1);
			
			return  Bank1;
		}
		else {
			return null;
		}

	}

	@Override
	public List<Bank> trancefor(Bank1 bank1) {
		Bank b1=repo.findById(bank1.getAcountnum()).get();
	
		Bank b2=repo.findById(bank1.getToacountnum()).get();
		
		if (b1.getAcountnum()==bank1.getAcountnum()&&b1.getName().equals(bank1.getName())&&b1.getPassword().equals(bank1.getPassword())) {
		b1.setAcountnum((int) (b1.getAmount()-bank1.getAmount()));
		repo.save(b1);
		b2.setAcountnum((int) (b2.getAmount()+bank1.getAmount()));
		repo.save(b2);
	
		List<Bank>list=List.of(b1,b2);
		}
		return list;
	/*/
	  /*Bank1 bank=new Bank1();
	  Bank1 b1=repo.findById()
	  bank.setAcountnum((int) (b1.getAmount()-bank1.getAmount()));
		bank.setAmount(bank.getAmount());
		bank.setAcountnum((int) (b2.getAmount()+bank1.getAmount()));
		bank.setAmount(bank.getAmount());
		repo.save(b1);
		repo.save(b2);
		return trancefor(bank1);*/
		
	}

	@Override
	public Bank delete(Bank acountnum) {
	Bank b=repo.findById(acountnum.getAcountnum()).get();
	if (b.getAcountnum()==acountnum.getAcountnum()&&b.getName().equals(acountnum.getName())&&b.getPassword().equals(acountnum.getPassword())) {
		
		
		repo.deleteById(acountnum.getAcountnum());
		}
		
	else {
           return null;
	}
	return b;
	}
}

	

	
	
	
	


